import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class StudentListService {
  //private baseUrl: string = "http://localhost/api/product.php?method=";
  private baseUrl: string = "http://localhost/registration/user/";
  constructor(public http: HttpClient) {     
  }

  getstudent(path: string){
      return this.http.get(this.baseUrl+path);
  }
}
