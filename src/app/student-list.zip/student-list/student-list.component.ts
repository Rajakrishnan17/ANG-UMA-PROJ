import { Component, OnInit } from '@angular/core';
import { StudentListService } from './student-list.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {
  //student: any;
  constructor( public student: StudentListService) { }

  ngOnInit() {
    this.studentList();
  }

  studentList(){
    console.log('studentlist');
    this.student.getstudent('getall').subscribe(
      (successresponse)=>{ console.log('success');

      },
      (errorresponse)=>{
        console.log('error');
      }

    );
  }


}
